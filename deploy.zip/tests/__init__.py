# Test package initialization
